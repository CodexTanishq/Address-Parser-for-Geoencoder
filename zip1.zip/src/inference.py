import sys
import io
import json
from pathlib import Path
from typing import Dict, Any, List
import torch
from transformers import AutoTokenizer, AutoModelForTokenClassification

if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from src import config
from src.bio import tokenize_with_spans


class AddressNERPredictor:
    """End-to-end inference engine for structured address extraction using fine-tuned MuRIL."""

    def __init__(self, model_dir: Path = config.MODELS_DIR / "muril_address_ner"):
        if not model_dir.exists():
            raise FileNotFoundError(
                f"Trained model not found at {model_dir}. Please train the model first with: python -m src.train_ner"
            )
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir)
        self.model = AutoModelForTokenClassification.from_pretrained(model_dir)
        self.model.to(self.device)
        self.model.eval()

    def predict(self, raw_address: str) -> Dict[str, Any]:
        """
        Extract structured address entities from raw messy address text.
        Returns a dictionary containing raw address, tokens, BIO tags, and structured entities.
        """
        token_tuples = tokenize_with_spans(raw_address)
        words = [t[0] for t in token_tuples]

        if not words:
            return {
                "raw_address": raw_address,
                "entities": {},
                "tokens": [],
                "tags": [],
            }

        # Tokenize with subword mapping
        encoding = self.tokenizer(
            words,
            is_split_into_words=True,
            max_length=config.MAX_SEQ_LENGTH,
            padding=False,
            truncation=True,
            return_tensors="pt",
        )

        input_ids = encoding["input_ids"].to(self.device)
        attention_mask = encoding["attention_mask"].to(self.device)
        word_ids = encoding.word_ids(batch_index=0)

        with torch.no_grad():
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            pred_ids = torch.argmax(logits, dim=-1)[0].cpu().tolist()

        # Map subword predictions back to words
        word_labels = ["O"] * len(words)
        seen_words = set()

        for subword_idx, word_idx in enumerate(word_ids):
            if word_idx is not None and word_idx not in seen_words:
                pred_label = config.ID2LABEL[pred_ids[subword_idx]]
                word_labels[word_idx] = pred_label
                seen_words.add(word_idx)

        # Assemble entities from BIO tags
        entities: Dict[str, List[str]] = {entity: [] for entity in config.ENTITIES}
        curr_entity = None
        curr_tokens = []

        for word, tag in zip(words, word_labels):
            if tag.startswith("B-"):
                if curr_entity and curr_tokens:
                    entities[curr_entity].append(" ".join(curr_tokens))
                curr_entity = tag[2:]
                curr_tokens = [word]
            elif tag.startswith("I-"):
                ent_type = tag[2:]
                if curr_entity == ent_type:
                    curr_tokens.append(word)
                else:
                    if curr_entity and curr_tokens:
                        entities[curr_entity].append(" ".join(curr_tokens))
                    curr_entity = ent_type
                    curr_tokens = [word]
            else:
                if curr_entity and curr_tokens:
                    entities[curr_entity].append(" ".join(curr_tokens))
                curr_entity = None
                curr_tokens = []

        if curr_entity and curr_tokens:
            entities[curr_entity].append(" ".join(curr_tokens))

        # Flatten singletons into values where appropriate
        structured_output = {
            "house_number": entities["HOUSE_NUMBER"][0] if entities["HOUSE_NUMBER"] else None,
            "streets": entities["STREET"],
            "ward": entities["WARD"][0] if entities["WARD"] else None,
            "landmarks": entities["LANDMARK"],
            "locality": entities["LOCALITY"][0] if entities["LOCALITY"] else None,
            "town": entities["TOWN"][0] if entities["TOWN"] else None,
            "pincode": entities["PINCODE"][0] if entities["PINCODE"] else None,
        }

        return {
            "raw_address": raw_address,
            "structured_address": structured_output,
            "tokens": words,
            "bio_tags": word_labels,
        }


def main():
    if len(sys.argv) > 1:
        query = " ".join(sys.argv[1:])
    else:
        # Default representative demo examples
        query = "6th Cross, 5th Main, ಚರ್ಚ್ ಹತ್ತಿರ, Kuvempu Layt, Kaveripura - 960102"

    predictor = AddressNERPredictor()
    result = predictor.predict(query)

    print("=" * 65)
    print("  MuRIL ADDRESS NER INFERENCE RESULT")
    print("=" * 65)
    print(f"Input Address: {result['raw_address']}\n")
    print("Structured Extraction:")
    for k, v in result["structured_address"].items():
        print(f"  {k:15s}: {v}")
    print("\nToken BIO Tags:")
    for tok, tag in zip(result["tokens"], result["bio_tags"]):
        print(f"  {tok:20s} -> {tag}")
    print("=" * 65)


if __name__ == "__main__":
    main()
