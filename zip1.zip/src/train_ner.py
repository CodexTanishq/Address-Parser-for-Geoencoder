import sys
import io
import json
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from transformers import (
    AutoTokenizer,
    AutoModelForTokenClassification,
    get_linear_schedule_with_warmup,
)
from seqeval.metrics import classification_report, f1_score, precision_score, recall_score
from sklearn.model_selection import GroupShuffleSplit
from tqdm import tqdm

if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

from src import config
from src.utils import set_seed


class AddressNERDataset(Dataset):
    """PyTorch Dataset for Address Token Classification with MuRIL."""

    def __init__(
        self,
        token_sequences: List[List[str]],
        label_sequences: List[List[str]],
        tokenizer: AutoTokenizer,
        label2id: Dict[str, int],
        max_length: int = config.MAX_SEQ_LENGTH,
    ):
        self.tokenizer = tokenizer
        self.label2id = label2id
        self.max_length = max_length
        self.features = []

        for words, tags in zip(token_sequences, label_sequences):
            encoding = tokenizer(
                words,
                is_split_into_words=True,
                max_length=max_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            )

            word_ids = encoding.word_ids(batch_index=0)
            label_ids = []
            previous_word_idx = None

            for word_idx in word_ids:
                if word_idx is None:
                    # Special tokens ([CLS], [SEP], [PAD]) get -100
                    label_ids.append(-100)
                elif word_idx != previous_word_idx:
                    # First subword token of a word
                    label_str = tags[word_idx] if word_idx < len(tags) else "O"
                    label_ids.append(self.label2id.get(label_str, self.label2id["O"]))
                else:
                    # Subsequent subwords of a word get -100 so loss is computed on the first subword token
                    label_ids.append(-100)
                previous_word_idx = word_idx

            self.features.append({
                "input_ids": encoding["input_ids"].squeeze(0),
                "attention_mask": encoding["attention_mask"].squeeze(0),
                "labels": torch.tensor(label_ids, dtype=torch.long),
            })

    def __len__(self) -> int:
        return len(self.features)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        return self.features[idx]


def create_template_signature(address_text: str) -> str:
    """
    Extract a normalized structural signature of the address
    to group similar address templates together and prevent test leakage.
    """
    text = address_text.lower()
    # Replace digits with <NUM>
    text = re.sub(r"\d+", "<NUM>", text)
    # Collapse whitespace and punctuation
    text = re.sub(r"[^\w\s<>]", " ", text)
    return " ".join(text.split()[:8])


def split_dataset(
    df: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Split the high-confidence dataset into train, val, test using
    GroupShuffleSplit on template signature to prevent data leakage.
    """
    df = df.copy()
    df["template_group"] = df["address_text"].apply(create_template_signature)

    # First split: Train (70%) vs Temp (30%)
    gss1 = GroupShuffleSplit(n_splits=1, train_size=0.70, random_state=config.RANDOM_SEED)
    train_idx, temp_idx = next(gss1.split(df, groups=df["template_group"]))

    train_df = df.iloc[train_idx].copy()
    temp_df = df.iloc[temp_idx].copy()

    # Second split: Val (15%) vs Test (15%) from Temp
    gss2 = GroupShuffleSplit(n_splits=1, train_size=0.50, random_state=config.RANDOM_SEED)
    val_sub_idx, test_sub_idx = next(gss2.split(temp_df, groups=temp_df["template_group"]))

    val_df = temp_df.iloc[val_sub_idx].copy()
    test_df = temp_df.iloc[test_sub_idx].copy()

    return train_df, val_df, test_df


def evaluate(
    model: AutoModelForTokenClassification,
    dataloader: DataLoader,
    device: torch.device,
    id2label: Dict[int, str],
) -> Tuple[float, float, float, str, Dict[str, Any]]:
    """Evaluate model on a dataloader using seqeval entity metrics."""
    model.eval()
    all_preds = []
    all_trues = []

    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1)

            for i in range(labels.size(0)):
                label_seq = labels[i].cpu().tolist()
                pred_seq = preds[i].cpu().tolist()

                clean_preds = []
                clean_trues = []
                for p, l in zip(pred_seq, label_seq):
                    if l != -100:
                        clean_preds.append(id2label[p])
                        clean_trues.append(id2label[l])

                if clean_trues:
                    all_preds.append(clean_preds)
                    all_trues.append(clean_trues)

    p = precision_score(all_trues, all_preds)
    r = recall_score(all_trues, all_preds)
    f1 = f1_score(all_trues, all_preds)
    report_str = classification_report(all_trues, all_preds, digits=4)
    report_dict = classification_report(all_trues, all_preds, output_dict=True)

    return p, r, f1, report_str, report_dict


def train_model() -> None:
    set_seed(config.RANDOM_SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    if torch.cuda.is_available():
        print(f"Device name: {torch.cuda.get_device_name(0)}")

    # 1. Load weak BIO dataset
    bio_path = config.BIO_DATASET_CSV
    if not bio_path.exists():
        raise FileNotFoundError(f"BIO dataset not found at {bio_path}. Run main.py first.")

    df = pd.read_csv(bio_path)
    # Filter for high-confidence addresses as mandated by Step 14 & 18
    high_conf_df = df[df["overall_confidence"] == config.CONF_HIGH].copy()
    print(f"Total dataset: {len(df)} | High-confidence training subset: {len(high_conf_df)}")

    # Parse tokens and labels from JSON columns
    high_conf_df["tokens_list"] = high_conf_df["tokens"].apply(json.loads)
    high_conf_df["labels_list"] = high_conf_df["bio_labels"].apply(json.loads)

    # 2. Leakage-free Group Split
    train_df, val_df, test_df = split_dataset(high_conf_df)
    print(f"Train set: {len(train_df)} | Val set: {len(val_df)} | Test set: {len(test_df)}")

    # 3. Initialize Tokenizer & Model
    print(f"Loading {config.TRANSFORMER_MODEL_NAME} tokenizer and model...")
    tokenizer = AutoTokenizer.from_pretrained(config.TRANSFORMER_MODEL_NAME)
    model = AutoModelForTokenClassification.from_pretrained(
        config.TRANSFORMER_MODEL_NAME,
        num_labels=len(config.BIO_LABELS),
        id2label=config.ID2LABEL,
        label2id=config.LABEL2ID,
    )
    model.to(device)

    # 4. Create Datasets & DataLoaders
    train_dataset = AddressNERDataset(
        train_df["tokens_list"].tolist(),
        train_df["labels_list"].tolist(),
        tokenizer,
        config.LABEL2ID,
    )
    val_dataset = AddressNERDataset(
        val_df["tokens_list"].tolist(),
        val_df["labels_list"].tolist(),
        tokenizer,
        config.LABEL2ID,
    )
    test_dataset = AddressNERDataset(
        test_df["tokens_list"].tolist(),
        test_df["labels_list"].tolist(),
        tokenizer,
        config.LABEL2ID,
    )

    train_loader = DataLoader(
        train_dataset, batch_size=config.TRAIN_BATCH_SIZE, shuffle=True
    )
    val_loader = DataLoader(
        val_dataset, batch_size=config.EVAL_BATCH_SIZE, shuffle=False
    )
    test_loader = DataLoader(
        test_dataset, batch_size=config.EVAL_BATCH_SIZE, shuffle=False
    )

    # 5. Optimizer & Scheduler
    optimizer = AdamW(model.parameters(), lr=config.LEARNING_RATE, weight_decay=0.01)
    total_steps = len(train_loader) * config.NUM_EPOCHS
    warmup_steps = int(0.1 * total_steps)
    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=warmup_steps, num_training_steps=total_steps
    )

    print(f"\nStarting MuRIL NER fine-tuning for {config.NUM_EPOCHS} epochs...")
    best_val_f1 = 0.0
    best_model_path = config.MODELS_DIR / "muril_address_ner"

    for epoch in range(1, config.NUM_EPOCHS + 1):
        model.train()
        total_loss = 0.0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{config.NUM_EPOCHS}")
        for batch in pbar:
            optimizer.zero_grad()
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()

            total_loss += loss.item()
            pbar.set_postfix({"loss": f"{loss.item():.4f}"})

        avg_loss = total_loss / len(train_loader)
        val_p, val_r, val_f1, _, _ = evaluate(
            model, val_loader, device, config.ID2LABEL
        )
        print(f"Epoch {epoch} Result: Loss={avg_loss:.4f} | Val P={val_p:.4f} R={val_r:.4f} F1={val_f1:.4f}")

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            print(f"  -> New best validation F1! Saving model checkpoint to {best_model_path}...")
            best_model_path.mkdir(parents=True, exist_ok=True)
            model.save_pretrained(best_model_path)
            tokenizer.save_pretrained(best_model_path)

    # 6. Final Evaluation on Held-Out Test Set
    print("\n" + "=" * 70)
    print("  FINAL EVALUATION ON HELD-OUT TEST SET (BEST CHECKPOINT)")
    print("=" * 70)
    best_model = AutoModelForTokenClassification.from_pretrained(best_model_path)
    best_model.to(device)

    test_p, test_r, test_f1, test_report, test_dict = evaluate(
        best_model, test_loader, device, config.ID2LABEL
    )
    print(test_report)
    print(f"Test Precision: {test_p:.4f}")
    print(f"Test Recall:    {test_r:.4f}")
    print(f"Test Macro F1:  {test_f1:.4f}")

    def convert_np(obj):
        if isinstance(obj, (np.integer, np.int64)):
            return int(obj)
        if isinstance(obj, (np.floating, np.float64)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return str(obj)

    # Save evaluation report to JSON
    report_output_path = config.OUTPUTS_DIR / "ner_evaluation_report.json"
    with open(report_output_path, "w", encoding="utf-8") as f:
        json.dump(test_dict, f, default=convert_np, indent=2, ensure_ascii=False)
    print(f"Evaluation report saved to {report_output_path}")


if __name__ == "__main__":
    train_model()
